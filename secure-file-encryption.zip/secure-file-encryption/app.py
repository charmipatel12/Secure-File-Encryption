import os
from tkinter import *
from tkinter import filedialog, messagebox
from cryptography.fernet import Fernet
import base64
import hashlib

# Generate key from password
def generate_key(password):
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key)

# Encrypt File
def encrypt_file():
    filepath = filedialog.askopenfilename()

    if filepath == "":
        return

    password = password_entry.get()

    if password == "":
        messagebox.showerror("Error", "Enter Password")
        return

    key = generate_key(password)
    cipher = Fernet(key)

    with open(filepath, "rb") as file:
        data = file.read()

    encrypted = cipher.encrypt(data)

    new_file = filepath + ".enc"

    with open(new_file, "wb") as file:
        file.write(encrypted)

    messagebox.showinfo("Success", "File Encrypted Successfully!")

# Decrypt File
def decrypt_file():
    filepath = filedialog.askopenfilename()

    if filepath == "":
        return

    password = password_entry.get()

    if password == "":
        messagebox.showerror("Error", "Enter Password")
        return

    key = generate_key(password)
    cipher = Fernet(key)

    try:
        with open(filepath, "rb") as file:
            encrypted = file.read()

        decrypted = cipher.decrypt(encrypted)

        output = filepath.replace(".enc", "")

        with open(output, "wb") as file:
            file.write(decrypted)

        messagebox.showinfo("Success", "File Decrypted Successfully!")

    except:
        messagebox.showerror("Error", "Wrong Password or Invalid File")

# GUI
root = Tk()
root.title("Secure File Encryption Tool")
root.geometry("450x300")

Label(root,
      text="Secure File Encryption Tool",
      font=("Arial",18,"bold")).pack(pady=20)

Label(root,text="Enter Password").pack()

password_entry = Entry(root,show="*",width=30)
password_entry.pack(pady=10)

Button(root,
       text="Encrypt File",
       command=encrypt_file,
       bg="green",
       fg="white",
       width=20).pack(pady=10)

Button(root,
       text="Decrypt File",
       command=decrypt_file,
       bg="blue",
       fg="white",
       width=20).pack(pady=10)

Button(root,
       text="Exit",
       command=root.destroy,
       bg="red",
       fg="white",
       width=20).pack(pady=10)

root.mainloop()